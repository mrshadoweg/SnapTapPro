﻿==================================================
[ENGLISH INSTRUCTIONS]
==================================================

To ensure SnapTap Pro works perfectly and starts smoothly with Windows, you must run it as an administrator.

Please follow these simple steps:

1. Right-click on the "SnapTapPro.exe" file.
2. Select "Properties" from the menu.
3. Go to the "Compatibility" tab.
4. Check the box: "Run this program as an administrator".
5. Click "Apply" and then click "OK".

Thank you for using SnapTap Pro!
Created By: mrshadoweg

==================================================
[تعليمات التشغيل باللغة العربية]
==================================================

لضمان عمل برنامج سناب تاب برو بشكل مثالي وتشغيله تلقائياً مع نظام ويندوز بدون مشاكل، يجب إعطائه صلاحيات المسؤول.

يرجى اتباع الخطوات البسيطة التالية بالترتيب:

1. اضغط بزر الفأرة الأيمن (كليك يمين) على ملف البرنامج التنفيذي.
2. اختر كلمة (Properties) أو "خصائص" من أسفل القائمة.
3. اذهب إلى تبويب (Compatibility) أو "التوافق" من الأعلى.
4. ضع علامة صح في المربع بجانب جملة:
   "Run this program as an administrator" أو "تشغيل هذا البرنامج كمسؤول".
5. اضغط على زر (Apply) أو "تطبيق" ثم زر (OK) أو "موافق".

شكراً لاستخدامك البرنامج!
تم التطوير بواسطة: mrshadoweg
==================================================